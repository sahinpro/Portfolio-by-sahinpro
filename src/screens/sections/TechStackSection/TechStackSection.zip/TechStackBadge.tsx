import type { TechStackItem } from "@/constants/techStack";
import type { IconType } from "react-icons";
import {
  SiExpress,
  SiFigma,
  SiGit,
  SiJavascript,
  SiMongodb,
  SiNextdotjs,
  SiNodedotjs,
  SiPhp,
  SiReact,
  SiShadcnui,
  SiSupabase,
  SiTailwindcss,
  SiVite,
  SiWoo,
  SiWordpress,
} from "react-icons/si";

type StackGlyph = (props: {
  className?: string;
  style?: React.CSSProperties;
}) => JSX.Element;

const asGlyph = (Icon: IconType): StackGlyph =>
  function StackGlyphIcon({ className, style }) {
    const Glyph = Icon as React.FC<{
      className?: string;
      style?: React.CSSProperties;
    }>;
    return <Glyph className={className} style={style} />;
  };

const ICON_MAP: Record<string, StackGlyph> = {
  SiJavascript: asGlyph(SiJavascript),
  SiReact: asGlyph(SiReact),
  SiNextdotjs: asGlyph(SiNextdotjs),
  SiVite: asGlyph(SiVite),
  SiTailwindcss: asGlyph(SiTailwindcss),
  SiShadcnui: asGlyph(SiShadcnui),
  SiNodedotjs: asGlyph(SiNodedotjs),
  SiExpress: asGlyph(SiExpress),
  SiWordpress: asGlyph(SiWordpress),
  SiWoo: asGlyph(SiWoo),
  SiPhp: asGlyph(SiPhp),
  SiMongodb: asGlyph(SiMongodb),
  SiGit: asGlyph(SiGit),
  SiFigma: asGlyph(SiFigma),
  SiSupabase: asGlyph(SiSupabase),
};

type TechStackBadgeProps = {
  item: TechStackItem;
  variant?: "default" | "git";
  accent?: string;
};

export function TechStackBadge({
  item,
  variant = "default",
  accent,
}: TechStackBadgeProps): JSX.Element {
  const Icon = ICON_MAP[item.icon];

  if (variant === "git") {
    return (
      <span
        className="group/badge inline-flex items-center gap-1.5 font-mono text-[11px] text-white/55 transition-colors duration-200 hover:text-white/90 sm:text-xs"
        style={
          accent
            ? ({
                "--stack-accent": accent,
              } as React.CSSProperties)
            : undefined
        }
      >
        <span className="text-emerald-400/45 transition-colors group-hover/badge:text-emerald-400/75">
          +
        </span>
        {Icon ? (
          <Icon
            className="size-3.5 shrink-0 opacity-80 transition-opacity group-hover/badge:opacity-100"
            style={{ color: item.color }}
            aria-hidden
          />
        ) : null}
        <span className="border-b border-transparent transition-colors group-hover/badge:border-[color:var(--stack-accent,rgba(52,211,153,0.35))]">
          {item.name}
        </span>
      </span>
    );
  }

  return (
    <span className="inline-flex items-center gap-2 rounded-xl border border-white/[0.08] bg-white/[0.04] px-3 py-2 text-sm font-medium text-white/85 transition-colors duration-200 hover:border-white/[0.14] hover:bg-white/[0.07]">
      {Icon ? (
        <Icon
          className="size-4 shrink-0"
          style={{ color: item.color }}
          aria-hidden
        />
      ) : null}
      {item.name}
    </span>
  );
}
