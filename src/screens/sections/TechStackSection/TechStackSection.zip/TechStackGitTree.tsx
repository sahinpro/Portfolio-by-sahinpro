import { scrollViewport, sectionEase } from "@/constants/scrollMotion";
import type { TechStackGroup } from "@/constants/techStack";
import { motion } from "framer-motion";
import { TechStackBadge } from "./TechStackBadge";

type BranchMeta = {
  slug: string;
  hash: string;
  message: string;
  accent: string;
  tag?: string;
};

const BRANCH_META: Record<string, BranchMeta> = {
  Frontend: {
    slug: "feat/frontend",
    hash: "7f2a9c1",
    message: "add frontend toolkit",
    accent: "#34d399",
    tag: "HEAD",
  },
  "Backend & CMS": {
    slug: "feat/backend-cms",
    hash: "4b8e1d3",
    message: "wire backend & cms layer",
    accent: "#38bdf8",
  },
  "Tooling & Workflow": {
    slug: "chore/tooling",
    hash: "c91f06a",
    message: "sync dev workflow stack",
    accent: "#a78bfa",
  },
};

type TechStackGitTreeProps = {
  groups: readonly TechStackGroup[];
};

export function TechStackGitTree({
  groups,
}: TechStackGitTreeProps): JSX.Element {
  const techCount = groups.reduce((n, g) => n + g.items.length, 0);

  return (
    <div className="relative mx-auto w-full max-w-4xl overflow-hidden rounded-2xl border border-white/[0.06] bg-[#070707]/80 shadow-[inset_0_1px_0_rgba(255,255,255,0.04)]">
      {/* Terminal chrome */}
      <div className="flex items-center gap-2 border-b border-white/[0.06] px-4 py-3">
        <span className="size-2.5 rounded-full bg-[#ff5f57]/90" aria-hidden />
        <span className="size-2.5 rounded-full bg-[#febc2e]/90" aria-hidden />
        <span className="size-2.5 rounded-full bg-[#28c840]/90" aria-hidden />
        <span className="ml-2 font-mono text-[10px] text-white/25 sm:text-[11px]">
          ~/portfolio — git-graph
        </span>
      </div>

      <div className="px-4 py-5 sm:px-6 sm:py-6">
        <motion.p
          className="mb-1 font-mono text-[11px] text-emerald-400/70 sm:text-xs"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={scrollViewport}
          transition={{ duration: 0.4, ease: sectionEase }}
        >
          <span className="text-emerald-400">sahin@portfolio</span>
          <span className="text-white/30">:</span>
          <span className="text-sky-400/80">~/stack</span>
          <span className="text-white/50">$</span> git log --oneline --graph
          --decorate --all
        </motion.p>

        <p className="mb-8 font-mono text-[10px] text-white/20 sm:text-[11px]">
          <span className="text-amber-400/55">main</span>
          <span className="text-white/15"> · </span>
          <span className="text-white/25">stack snapshot</span>
          <span className="text-white/15"> · </span>
          <span className="text-white/20">{groups.length} branches</span>
        </p>

        {/* Root commit */}
        <div className="relative mb-6 flex items-center gap-3 pl-1 font-mono text-[10px] sm:text-[11px]">
          <div className="relative flex w-9 shrink-0 justify-center sm:w-10">
            <div
              className="size-2.5 rounded-full border-2 border-emerald-400/90 bg-[#070707] shadow-[0_0_12px_rgba(52,211,153,0.35)]"
              aria-hidden
            />
            <div
              className="absolute left-1/2 top-full h-6 w-px -translate-x-1/2 bg-gradient-to-b from-emerald-500/60 to-emerald-500/15"
              aria-hidden
            />
          </div>
          <p className="text-white/30">
            <span className="text-amber-400/70">e4c2b08</span>
            <span className="text-white/15"> (</span>
            <span className="text-amber-400/55">main</span>
            <span className="text-white/15">)</span>
            <span className="ml-2 hidden text-white/22 sm:inline">
              init production stack
            </span>
          </p>
        </div>

        <div className="relative flex flex-col">
          {/* Shared trunk */}
          <div
            className="pointer-events-none absolute bottom-4 left-[18px] top-0 w-px bg-gradient-to-b from-emerald-500/50 via-sky-500/25 to-violet-500/15 sm:left-[20px]"
            aria-hidden
          />

          {groups.map((group, index) => {
            const meta = BRANCH_META[group.title];
            const branch = meta?.slug ?? group.title.toLowerCase();
            const hash = meta?.hash ?? "0000000";
            const message = meta?.message ?? "update stack";
            const accent = meta?.accent ?? "#34d399";
            const isLast = index === groups.length - 1;
            const layer = branch.split("/")[1] ?? "layer";

            return (
              <motion.div
                key={group.title}
                initial={{ opacity: 0, x: -12 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={scrollViewport}
                transition={{
                  duration: 0.5,
                  delay: index * 0.1,
                  ease: sectionEase,
                }}
                className="group/branch relative flex gap-3 pb-10 last:pb-4 sm:gap-4"
              >
                {/* Branch node + connector */}
                <div className="relative w-9 shrink-0 sm:w-10">
                  <div
                    className="absolute left-[18px] top-5 z-10 size-2.5 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 bg-[#070707] shadow-[0_0_14px_var(--branch-glow)] sm:left-5"
                    style={
                      {
                        borderColor: accent,
                        "--branch-glow": `${accent}44`,
                      } as React.CSSProperties
                    }
                    aria-hidden
                  />
                  <div
                    className="absolute left-[18px] top-5 h-px w-full sm:left-5"
                    style={{ backgroundColor: `${accent}66` }}
                    aria-hidden
                  />
                </div>

                {/* Commit + stack */}
                <div className="min-w-0 flex-1 pt-1">
                  <div className="mb-2.5 font-mono text-[11px] leading-relaxed sm:text-xs">
                    <span className="text-emerald-500/40">
                      {isLast ? "└─" : "├─"}
                    </span>
                    <span className="ml-1 text-amber-400/75">
                      {hash.slice(0, 7)}
                    </span>
                    <span className="text-white/18"> (</span>
                    <span style={{ color: accent }}>{branch}</span>
                    {meta?.tag ? (
                      <>
                        <span className="text-white/18">, </span>
                        <span className="text-rose-400/75">{meta.tag}</span>
                      </>
                    ) : null}
                    <span className="text-white/18">)</span>
                    <span className="ml-2 hidden text-white/28 sm:inline">
                      {message}
                    </span>
                  </div>

                  <p className="mb-2.5 text-[10px] font-semibold uppercase tracking-[0.2em] text-white/28 transition-colors duration-300 group-hover/branch:text-white/42">
                    {group.title}
                  </p>

                  <p className="mb-2.5 font-mono text-[10px] text-white/16">
                    <span className="text-emerald-500/38">+++</span> stack/
                    {layer}.txt
                  </p>

                  <div className="flex flex-wrap gap-x-3 gap-y-2">
                    {group.items.map((item, itemIndex) => (
                      <motion.div
                        key={item.name}
                        initial={{ opacity: 0, y: 5 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        viewport={scrollViewport}
                        transition={{
                          duration: 0.32,
                          delay: index * 0.08 + itemIndex * 0.035,
                          ease: sectionEase,
                        }}
                      >
                        <TechStackBadge
                          item={item}
                          variant="git"
                          accent={accent}
                        />
                      </motion.div>
                    ))}
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>

        <motion.p
          className="mt-2 border-t border-white/[0.05] pt-4 font-mono text-[10px] text-white/22 sm:text-[11px]"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={scrollViewport}
          transition={{ duration: 0.4, delay: 0.3, ease: sectionEase }}
        >
          <span className="text-emerald-400/50">✓</span> working tree clean
          <span className="mx-2 text-white/10">·</span>
          <span className="text-white/25">
            {techCount} technologies tracked
          </span>
          <span
            className="ml-1.5 inline-block h-3.5 w-1.5 animate-pulse bg-emerald-400/55 align-middle"
            aria-hidden
          />
        </motion.p>
      </div>
    </div>
  );
}
